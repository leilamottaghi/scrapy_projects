import scrapy
from ..items import FlotutorialItem
from selenium import webdriver
import time
# chrome_options = webdriver.ChromeOptions()
import unicodedata
import re
import logging
from scrapy.linkextractors import LinkExtractor
import sqlite3
# cod
import os 
import selenium
# from woocommerce import API
from bs4 import BeautifulSoup
import json
import sqlite3 
import csv
import logging
import requests
import sys   
from urllib.request import Request, urlopen
import time
# import path
import logging
import platform
from selenium import webdriver
from scrapy.crawler import CrawlerProcess
import scrapy
from scrapy_selenium import SeleniumRequest
from selenium import webdriver
from scrapy.selector import Selector
import time
# from .. items import ScrapysplashCrawlerItem
from selenium.webdriver.chrome.options import Options
from shutil import which
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
process = CrawlerProcess(get_project_settings())


class FloSpiderSpider(scrapy.Spider):
    name = 'flo'
    # allowed_domains = ['flo.com']
    # page_number = 2
    page_number = 1

    start_urls = [
    # "https://www.flo.com.tr/marka/caterpillar?cinsiyet=kadin",
    # "https://www.flo.com.tr/tisort?cinsiyet=kadin",
    # "https://www.flo.com.tr/ayakkabi?cinsiyet=kadin",
    # "https://www.flo.com.tr/sneaker?cinsiyet=kadin",
    # "https://www.flo.com.tr/spor-ayakkabi?cinsiyet=kadin",
    # "https://www.flo.com.tr/gunluk-ayakkabi?cinsiyet=kadin",
    # "https://www.flo.com.tr/topuklu-ayakkabi?cinsiyet=kadin",
    # "https://www.flo.com.tr/klasik-ayakkabi?cinsiyet=kadin",
    "https://www.flo.com.tr/babet?cinsiyet=kadin",
    "https://www.flo.com.tr/bot?cinsiyet=kadin",
    "https://www.flo.com.tr/cizme?cinsiyet=kadin",
    "https://www.flo.com.tr/outdoor-ayakkabi?cinsiyet=kadin",
    "https://www.flo.com.tr/sandalet?cinsiyet=kadin",
    "https://www.flo.com.tr/terlik?cinsiyet=kadin",
    "https://www.flo.com.tr/ev-ayakkabisi?cinsiyet=kadin",
    # "https://www.flo.com.tr/ayakkabi?cinsiyet=erkek",
    # "https://www.flo.com.tr/sneaker?cinsiyet=erkek",
    # "https://www.flo.com.tr/spor-ayakkabi?cinsiyet=erkek",
    # "https://www.flo.com.tr/gunluk-ayakkabi?cinsiyet=erkek",
    # "https://www.flo.com.tr/klasik-ayakkabi?cinsiyet=erkek",
    # "https://www.flo.com.tr/babet?cinsiyet=erkek",
    # "https://www.flo.com.tr/bot?cinsiyet=erkek",
    # "https://www.flo.com.tr/outdoor-ayakkabi?cinsiyet=erkek",
    # "https://www.flo.com.tr/sandalet?cinsiyet=erkek",
    # "https://www.flo.com.tr/terlik?cinsiyet=erkek",
    # "https://www.flo.com.tr/ev-ayakkabisi?cinsiyet=erkek",

    # "https://www.flo.com.tr/marka/kinetix",
    # "https://www.flo.com.tr/marka/lumberjack",
    # "https://www.flo.com.tr/marka/dockers-by-gerli",
    # "https://www.flo.com.tr/marka/nine-west",
    # "https://www.flo.com.tr/marka/nine-west"
    # "https://www.flo.com.tr/marka/butigo",
    # "https://www.flo.com.tr/marka/nike",
    # "https://www.flo.com.tr/marka/Adidas",
    # "https://www.flo.com.tr/marka/reebok",
    # "https://www.flo.com.tr/marka/hummel",


    # "https://www.flo.com.tr/marka/nine-west",
    # "https://www.flo.com.tr/marka/polaris",
    # "https://www.flo.com.tr/marka/polaris-5-nokta",
    # "https://www.flo.com.tr/marka/lumberjack",
    # "https://www.flo.com.tr/marka/dockers-by-gerli"
   
    ]


    # def __init__(self):
    #     self.driver = webdriver.ChromeOptions()  
    def __init__(self):
        self.driver = webdriver.Chrome()
        self.driver.implicitly_wait(60)

    # def start_requests(self):
    #     yield SeleniumRequest(
    #         url = "https://practice.geeksforgeeks.org/courses/online",
    #         wait_time = 3,
    #         screenshot = True,
    #         callback = self.parse,
    #         dont_filter = True,
    #         script='window.scrollTo(0, document.body.scrollHeight);',
    #         headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:48.0) Gecko/20100101 Firefox/48.0'}
    #         # headers={"User-Agent": "My UserAgent"},
    #         # meta={"proxy": "http://127.0.0.1:11080"}
    #         )

    

    BASE_URL ="https://www.flo.com.tr"

    # def parse(self, response):
    #     for sel in response.xpath("//div[@class ='js-product-vertical col-6 col-lg-4 listing__col-product']"):
    #         link_list = response.css('div.product__image a::attr(href)').getall()
    #         for link_listi in link_list:
    #             absolute_url = self.BASE_URL + link_listi  
    #             # yield scrapy.Request(absolute_url, callback=self.parse_attr)
    #             yield SeleniumRequest(absolute_url, callback=self.parse_attr)
    def parse(self, response):
        self.driver = webdriver.Chrome()
        # self.driver.get(self.start_urls[0])
        self.driver.get(response.url)
        SCROLL_PAUSE_TIME = 0.5
        SCROLL_LENGTH = 200
        page_height = int(self.driver.execute_script("return document.body.scrollHeight"))
        scrollPosition = 0
        while scrollPosition < page_height:
            scrollPosition = scrollPosition + SCROLL_LENGTH
            self.driver.execute_script("window.scrollTo(0, " + str(scrollPosition) + ");")
            time.sleep(SCROLL_PAUSE_TIME)
        sel = Selector(text=self.driver.page_source)    
        for item in sel.xpath("//div[@class ='js-product-vertical col-6 col-lg-4 listing__col-product']"):
            link_list = item.css('div.product__image a::attr(href)')[0].extract()
            absolute_url = self.BASE_URL + link_list
            # yield {
            #     'absolute_url':absolute_url
            #     }
            yield scrapy.Request(absolute_url, callback=self.parse_attr)
            # yield SeleniumRequest(absolute_url, callback=self.parse_attr, headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:48.0) Gecko/20100101 Firefox/48.0'} )


#----------------next page----------------
        # while True:            
        try:
            next_page_url = sel.css('li.page-item.next a').attrib['href']
            if next_page_url is not None:
                next_page =  "https://www.flo.com.tr" + str(next_page_url)
                yield response.follow(next_page, callback=self.parse)
        except :
            return
        self.driver.close()

#---------------- other  Method next page----------------

        
        # next_page_url = response.xpath('//a[contains(text(),"İleri")]/@href').extract_first()
        # next_page_url = sel.xpath('//a[contains(text(),"İleri")]/@href')
        # next_page_url = sel.xpath("//li[@class ='page-item next']/a/@href")
        # if next_page_url:
        #     next_page =  "https://www.flo.com.tr/" + str(next_page_url)
        #     yield scrapy.Request(next_page, callback=self.parse)


        # next_page = 'https://www.flo.com.tr/tisort?cinsiyet=kadin&page='+ str(FloSpiderSpider.page_number)
        # if FloSpiderSpider.page_number <= 2:
        #     FloSpiderSpider.page_number +=1
        #     yield response.follow(next_page, callback=self.parse)


        # next_page = response.css('li.page-item.next').extract()
        # if next_page:
        #     FloSpiderSpider.page_number += 1

        #     FloSpiderSpider_ayakkabi.page_number += 1
        #     next_page_url = 'https://www.flo.com.tr/ayakkabi?cinsiyet=kadin&page=' + str(FloSpiderSpider_ayakkabi.page_number)
        #     request = scrapy.Request(url=next_page_url)
        #     yield request



        # try:
        #     # self.driver.find_element_by_link_text("İleri").click()
        #     self.driver.find_element_by_xpath("//a[contains(text(), 'İleri')]").click()

        # except Exception:
        #     return
        
#--------------------------------------------------------------------------------------------------------------------

    def parse_attr(self, response):
        items = FlotutorialItem()
        items["url"] = response.url
        barcode_url = str(response.url)
        r_barcode = barcode_url[barcode_url.rfind("-"):]
        barcode = r_barcode.replace("-","").replace("?campaign=c_49","")  
        items["barcode"] = barcode
        
        title = response.css('h1.product__name.description.text-capital.order-1.js-product-name::text').extract()[0].strip()
        items["title"] = title

        saleprice_str = response.css("span.product__prices-sale::text")[0].extract().replace("TL", "")
        saleprice = saleprice_str[:saleprice_str.find(",")]
        items["saleprice"] = int((int(saleprice)*4700+150000)/1000)*1000

        try:
            price_str = response.xpath("//div[@class = 'product__prices  with-third-price'][1]").css('span.product__prices-actual span::text').extract().replace("TL", "")
            price = price_str[:price_str.find(",")]
            items["price"] = int((int(price)*4700+150000)/1000)*1000
        except AttributeError:
            items['price'] = items["saleprice"]
       
        sizes_str = response.xpath("//select[@class ='js-select-size-options']/option").getall()
        for size_str in sizes_str:
            if "disabled"not in size_str:
                sizes_string = response.xpath("//select[@class ='js-select-size-options']/option").css('::text').getall() 
                size_list = []
                for size_string in sizes_string:
                    size = size_string.strip().replace("STD","تک سایز")
                    if size != "Lütfen Beden Seçiniz":
                        if "(Stok Yok)" not in str(size):
                            size_list.append(size)
                sizes = "|".join(size_list)
                items["sizes"]= str(sizes)

        return items
# --------------------------------------------------------------------------------------


# --------------------------------------------------------------------------------------

# process = CrawlerProcess()
# process.crawl(ayakkabi)
# process.crawl(sneaker)
# process.start() 