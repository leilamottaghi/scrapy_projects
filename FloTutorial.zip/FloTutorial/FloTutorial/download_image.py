def download_images():
	# fetch_sku("status=draft")

	browser = webdriver.Chrome(executable_path=CHROME_PATH, options = chrome_options)
	c.execute('SELECT * FROM urls')
	urls = c.fetchall()
	for url in urls:
		have_code = None  
		c.execute('SELECT barcode FROM pre_process WHERE url LIKE ?',(url[1],))
		barcode = c.fetchone()
		if barcode:
			print(barcode[0])
			c.execute("SELECT * FROM product_sku WHERE wp_sku LIKE ?",(str(barcode[0])+"%",))
			have_code = c.fetchone()
			have_code = True
			if have_code:
				print("b")
				if not have_file(barcode):
					time.sleep(2)
					url = url[1]
					browser.get(url)
					for i in range(1,100):
						time.sleep(.1)
						precent = str(i)
						script_string = "window.scrollTo(0, document.body.scrollHeight - (document.body.scrollHeight * %s / 100 ) );" %(str(i))
						browser.execute_script(script_string)
					image_gallery = browser.find_element_by_xpath("//div[contains(@class, 'col-12 col-lg-8')]")
					if image_gallery:
						print("ooooooooooooooooo88888888888") 
						try:
							images = [image.get_attribute("src") for image in image_gallery.find_elements_by_tag_name('img')]
							alphab = ['m','a','b','c','d','e','f','g','h','i','j','k','l']
							for image in images:
								try:
									time.sleep(2)
									# print("image url >>>>>>>> " + imag)
									# width_start = image.find("w/")
									# width_end = image.find("/",width_start+2)
									# new_image = image[:width_start]+ "w/1000" + image[width_end:]
									# image = imag[:imag.find("?")]
									new_image = image.replace("mncropresize/450/450/","")
									print("after changing image >>>>>")
									print(str(new_image))
									req = Request(str(new_image), headers={'User-Agent': 'Mozilla/5.0'})
									f = urlopen(req)
									with open("img/%s%s.jpeg"%(barcode,alphab[0]), "wb") as local_file:
										local_file.write(f.read())
									local_file.close()
									alphab.pop(0)
								except Exception as e:
									print(e)
						except Exception as e:
							print(e)
		