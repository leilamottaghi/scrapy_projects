import selenium
from woocommerce import API
from selenium import webdriver
import json
import sqlite3
import time
import scrapy
conn = sqlite3.connect('flo.db')
curr = conn.cursor()



wcapi = API(
	url="https://shahremun.com",
	consumer_key="",
	consumer_secret="",
    version="wc/v3",
    timeout= 190
)


def fetch_sku(options = None):

	api_string = "products?per_page=%d&page=%d"

	if options:
		api_string = "products?per_page=%d&page=%d" + "&" + options

	i = 1
	while True:
		try:
			result = wcapi.get(api_string%(60,i)).json()
			if result:
				print("page:" + str(i))
				i += 1
				for product in result:
					wp_sku = product['sku'].encode('utf-8')
					wp_id = int(product['id'])
					if (len(product['variations']) != 0 ):
						wp_variation = int(product['variations'][0])
					else:
						wp_variation = int(0000)
					connection = sqlite3.connect("flo.db")
					crsr = connection.cursor()
					crsr.execute('SELECT * FROM product_sku WHERE wp_sku = ?',(wp_sku,))
					record = crsr.fetchall()
					if not record:
						crsr.execute('INSERT INTO product_sku VALUES (?,?,?,?)',(None,wp_sku,wp_id,wp_variation))
						connection.commit()
						connection.close()
			else:
				return
		except Exception as e:
			print(e)
			i -= 1
			time.sleep(50)


fetch_sku()
