# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
import sqlite3


class FlotutorialItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    # pass
    url = scrapy.Field()
    barcode = scrapy.Field()
    saleprice = scrapy.Field()
    price = scrapy.Field()
    title = scrapy.Field()
    sizes = scrapy.Field()
    # sku = scrapy.Field()

    




# from dataclasses import dataclass, field
# from typing import Optional

# @dataclass
# class InventoryItem:
#     name: Optional[str] = field(default=None)
#     price: Optional[float] = field(default=None)
#     stock: Optional[int] = field(default=None)
#     barcode: Optional[str] = field(default=None)


