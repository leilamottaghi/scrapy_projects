import scrapy
from items import FlotutorialItem
from selenium import webdriver
import time
# chrome_options = webdriver.ChromeOptions()
import unicodedata
import re
import logging
from scrapy.linkextractors import LinkExtractor
import sqlite3
# cod
import os 
import selenium
from woocommerce import API
from bs4 import BeautifulSoup
import json
import sqlite3
import csv
import logging
import requests
import sys   
from urllib.request import Request, urlopen
import time
# import path
import logging
import platform
from selenium import webdriver
from scrapy.crawler import CrawlerProcess



wcapi = API(
    url="https://shahremun.com",
    consumer_key="ck_c3668f8f752fc1ba5c8b1f698720d5ffd19ad2af",
    consumer_secret="cs_8aa592e0336b6ba2dbf6e704a4c05c7e6012d9ef",
    version="wc/v3",
    timeout= 190
)


class FloSpiderSpider2(scrapy.Spider):
    name = 'flo_erkek'
    # allowed_domains = ['flo.com']
    page_number = 2
    start_urls = [
    # 'https://www.flo.com.tr/tisort?cinsiyet=kadin&page=1',
    'https://www.flo.com.tr/tisort?cinsiyet=erkek&page=1'

    # ,'https://www.flo.com.tr/canta?page=1'
    ]
    # def __init__(self):
    #     self.driver = webdriver.ChromeOptions()
    BASE_URL ="https://www.flo.com.tr/urun/"

    def parse(self, response):
        # ---------------
        # logger = logging.getLogger()
        # logger.warning("This is a warning")
        # logger.info('Parse function called on %s', response.url)
        # -----
        # items = FlotutorialItem()

        # for link in self.link_extractor.extract_links(response):
        #     yield Request(link.url, callback=self.parse_attr)

        # def parse(self, response):
        # # We want to inspect one specific response.
        # if ".org" in response.url:
        #     from scrapy.shell import inspect_response
        #     inspect_response(response, self)

        for sel in response.xpath("//div[@class ='js-product-vertical col-6 col-lg-4 listing__col-product']"):
            link_list = response.css('div.product__image a::attr(href)').getall()
            for link_listi in link_list:
                
                # items["barcode"] =barcode
                absolute_url = self.BASE_URL + link_listi
                 # barcode_url = response.url[:response.url.find("?")+1]
                # barcode_start = str(barcode_url).rfind("-")
                        # # barcode_end = str(url).find("?campaign")
                # r_barcode = barcode_url[barcode_start+1:]   
                # barcode_url =response.url
                # barcode_str= re.search(str(response.url), '-')
                # items["barcode"] = barcode_str

                # barcode_str = str(link_listi)[:str(link_listi).find("?")]  
                # yield{"barcode_str":barcode_str}    
                yield scrapy.Request(absolute_url, callback=self.parse_attr)

            # yield items

        next_page = 'https://www.flo.com.tr/tisort?cinsiyet=kadin&page='+ str(FloSpiderSpider.page_number)
        if FloSpiderSpider.page_number <= 1:
            FloSpiderSpider.page_number +=1
            yield response.follow(next_page, callback=self.parse)

    def parse_attr(self, response):
        items = FlotutorialItem()
        items["link_list"] = response.url
        barcode_url = str(response.url)
        r_barcode = barcode_url[barcode_url.rfind("-"):]
        barcode = r_barcode.replace("-","")  
        items["barcode"] = barcode
        

        title = response.css('h1.product__name.description.text-capital.order-1.js-product-name::text').extract()[0].strip()
        items["title"] = title

        saleprice_str = response.css("span.product__prices-sale::text")[0].extract().replace("TL", "")
        saleprice = saleprice_str[:saleprice_str.find(",")]
        items["saleprice"] = int((int(saleprice)*4700+170000)/1000)*1000

        try:
            price_str = response.xpath("//div[@class = 'product__prices  with-third-price'][1]").css('span.product__prices-actual span::text').extract().replace("TL", "")
            price = price_str[:price_str.find(",")]
            items["price"] = int((int(price)*4700+170000)/1000)*1000
        except AttributeError:
            items['price'] = items["saleprice"]
       
        sizes_str = response.xpath("//select[@class ='js-select-size-options']/option").getall()
        for size_str in sizes_str:
            if "disabled"not in size_str:
                sizes_string = response.xpath("//select[@class ='js-select-size-options']/option").css('::text').getall() 
                size_list = []
                for size_string in sizes_string:
                    size = size_string.strip().replace("STD","تک سایز")
                    if size != "Lütfen Beden Seçiniz":
                        if "(Stok Yok)" not in str(size):
                            size_list.append(size)
                sizes = "|".join(size_list)
                items["sizes"]= str(sizes)

        return items

class FloSpiderSpider(scrapy.Spider):
    name = 'flo'
    # allowed_domains = ['flo.com']
    page_number = 2
    start_urls = [
    'https://www.flo.com.tr/tisort?cinsiyet=kadin&page=1',
    # 'https://www.flo.com.tr/tisort?cinsiyet=erkek&page=1'

    # ,'https://www.flo.com.tr/canta?page=1'
    ]
    # def __init__(self):
    #     self.driver = webdriver.ChromeOptions()
    BASE_URL ="https://www.flo.com.tr/urun/"

    def parse(self, response):
        # ---------------
        # logger = logging.getLogger()
        # logger.warning("This is a warning")
        # logger.info('Parse function called on %s', response.url)
        # -----
        # items = FlotutorialItem()

        # for link in self.link_extractor.extract_links(response):
        #     yield Request(link.url, callback=self.parse_attr)

        # def parse(self, response):
        # # We want to inspect one specific response.
        # if ".org" in response.url:
        #     from scrapy.shell import inspect_response
        #     inspect_response(response, self)

        for sel in response.xpath("//div[@class ='js-product-vertical col-6 col-lg-4 listing__col-product']"):
            link_list = response.css('div.product__image a::attr(href)').getall()
            for link_listi in link_list:
                
                # items["barcode"] =barcode
                absolute_url = self.BASE_URL + link_listi
                 # barcode_url = response.url[:response.url.find("?")+1]
                # barcode_start = str(barcode_url).rfind("-")
                        # # barcode_end = str(url).find("?campaign")
                # r_barcode = barcode_url[barcode_start+1:]   
                # barcode_url =response.url
                # barcode_str= re.search(str(response.url), '-')
                # items["barcode"] = barcode_str

                # barcode_str = str(link_listi)[:str(link_listi).find("?")]  
                # yield{"barcode_str":barcode_str}    
                yield scrapy.Request(absolute_url, callback=self.parse_attr)

            # yield items

        next_page = 'https://www.flo.com.tr/tisort?cinsiyet=kadin&page='+ str(FloSpiderSpider.page_number)
        if FloSpiderSpider.page_number <= 1:
            FloSpiderSpider.page_number +=1
            yield response.follow(next_page, callback=self.parse)

    def parse_attr(self, response):
        items = FlotutorialItem()
        items["link_list"] = response.url
        barcode_url = str(response.url)
        r_barcode = barcode_url[barcode_url.rfind("-"):]
        barcode = r_barcode.replace("-","")  
        items["barcode"] = barcode
        

        title = response.css('h1.product__name.description.text-capital.order-1.js-product-name::text').extract()[0].strip()
        items["title"] = title

        saleprice_str = response.css("span.product__prices-sale::text")[0].extract().replace("TL", "")
        saleprice = saleprice_str[:saleprice_str.find(",")]
        items["saleprice"] = int((int(saleprice)*4700+170000)/1000)*1000

        try:
            price_str = response.xpath("//div[@class = 'product__prices  with-third-price'][1]").css('span.product__prices-actual span::text').extract().replace("TL", "")
            price = price_str[:price_str.find(",")]
            items["price"] = int((int(price)*4700+170000)/1000)*1000
        except AttributeError:
            items['price'] = items["saleprice"]
       
        sizes_str = response.xpath("//select[@class ='js-select-size-options']/option").getall()
        for size_str in sizes_str:
            if "disabled"not in size_str:
                sizes_string = response.xpath("//select[@class ='js-select-size-options']/option").css('::text').getall() 
                size_list = []
                for size_string in sizes_string:
                    size = size_string.strip().replace("STD","تک سایز")
                    if size != "Lütfen Beden Seçiniz":
                        if "(Stok Yok)" not in str(size):
                            size_list.append(size)
                sizes = "|".join(size_list)
                items["sizes"]= str(sizes)

        return items
# --------------------------------------------------------------------------------------
process = CrawlerProcess()
process.crawl(FloSpiderSpider2)
# process.crawl(FloSpiderSpider)
process.start()