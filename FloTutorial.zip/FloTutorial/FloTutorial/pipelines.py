# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import sqlite3

# useful for handling different item types with a single interface

# useful for handling different item types with a single interface
from itemadapter import ItemAdapter


class FlotutorialPipeline:
	def __init__(self):
		self.create_connection()
	def create_connection(self):
		self.conn = sqlite3.connect("flo.db")
		self.curr = self.conn.cursor()
		def create_table(self):
			self.curr.execute("""DROP TABLE IF EXISTE url """)
			self.curr.execute("""create table url(
				id INTEGER PRIMARY KEY AUTOINCREMENT,	
				url text UNIQUE, barcode text, done int
				)""")
			self.curr.execute("""DROP TABLE IF EXISTE pre_process """)
			self.curr.execute("""create table pre_process
			 (id integer primary key, barcode text UNIQUE, size text, price int,sales_price int, done int,url text)""")
			self.curr.execute("""create table updateurls
			 (id integer primary key, barcode text, size text, price int,sales_price int, done int,url text)""")
			
			# self.conn.execute("""create table product_sku (id integer primary key,wp_sku,wp_id,wp_variation)""")

	def process_item(self, item, spider):
		self.store_db(item)
		# print("Pipline:" + item['title'][0])
		return item

	def store_db(self,item):
		self.curr.execute('insert or ignore into url values(?,?,?,?)', (None,str(item['url']),str(item['barcode']),1))
		self.conn.commit()
		self.curr.execute('insert or ignore into pre_process VALUES (?,?,?,?,?,?,?)',(None,str(item['barcode']),str(item['sizes']),item['price'],item['saleprice'],0,str(item['url']),))
		self.conn.commit()
		# self.curr.execute('insert into updateurls VALUES (?,?,?,?,?,?,?)',(None,str(item['barcode']),str(item['sizes']),item['price'],item['saleprice'],0,str(item['link_list']),))
		# self.conn.commit()
		
		# self.conn.execute('INSERT INTO product_sku VALUES (?,?,?,?)',(None,wp_sku,wp_id,wp_variation))
		# self.conn.commit()




    # def process_item(self, item, spider):
    #     return item

