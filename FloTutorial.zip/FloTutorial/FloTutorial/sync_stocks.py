import selenium
from woocommerce import API
from selenium import webdriver
import json
import sqlite3
import time
import scrapy
conn = sqlite3.connect('flo.db')
curr = conn.cursor()



wcapi = API(
	url="https://shahremun.com",
	consumer_key="ck_c3668f8f752fc1ba5c8b1f698720d5ffd19ad2af",
	consumer_secret="cs_8aa592e0336b6ba2dbf6e704a4c05c7e6012d9ef",
    version="wc/v3",
    timeout= 190
)

connection = sqlite3.connect("flo.db")
crsr = connection.cursor()


def json_product(barcode, size, price,sales_price,attr,in_wp_stock = False,on_sale = False):
	if price > sales_price:
		on_sale = True

	variation_data = {
		"regular_price" : str(price),
		"sale_price" : str(sales_price)
	}

	if in_wp_stock:
		data = {
			"sku": barcode,
			"type": "variable",
    		"attributes": [
    			{
    				"name": "pa_size",
    				"id": 23,
    				"visible": False,
    				"variation": True,
    				"options": size
    			}
    		]
		}
	else:
		data = {
		    "name": barcode[:-1]  + " " + "lumberjack_men_women_shoes",
		    "sku": barcode,
		    "type": "variable",
		    "status": "draft",
		    "managing_stock":True,
		    "stock_quantity":2,
		    "in_stock":True,
		    "attributes": [
		        {
		            "name": "pa_size",
		            "id": 23,
		            "visible": False,
		            "variation": True,
		            "options":size
		        }
		    ]
		}

	return data,variation_data



def add_update(prev_barcode,cur_barcode, size_list, price, sales_price):
	# t = ('8W0892Z8-M3P lcwd2',)
	# c.execute("SELECT * FROM product_sku WHERE wp_sku Like '100224151flwf7'")
	t = (str(prev_barcode),)
	connection = sqlite3.connect("flo.db")
	crsr = connection.cursor()
	crsr.execute('SELECT * FROM product_sku WHERE wp_sku Like ?', (t))
	p_detail = crsr.fetchall()
	connection.commit()
	connection.close()
	print("ISSS AVAIALABEL >>>>>" + str(p_detail) )

	print("this is where we eant >>>>")
	if p_detail:
		print("yeeeeeeeeeeeeeeeeeeeeeeeeeeej")
		attr_id = int(p_detail[0][3])
		print("attr_id:" + str(attr_id))
		wp_id = int(p_detail[0][2])
		print("wp_id:" + str(wp_id))
		old_json,p_variation = json_product(cur_barcode, size_list, price,sales_price,attr_id,in_wp_stock = True)
		print("after json")
		json_result = wcapi.put("products/%s"%wp_id, old_json).json()
		# print(json_result)
		variation_result = wcapi.put("products/%s/variations/%s" % (wp_id,attr_id), p_variation)
		# print(variation_result)
		print("is available")

		print(prev_barcode)
		print(cur_barcode)
		print(size_list)
		print(price)
		print(sales_price)

	# connection.commit()
	# connection.close()
	# else:
	# 	attr_id = None
	# 	wp_id= ""
	# 	new_json,p_variation = json_product(cur_barcode, size_list, price,sales_price,attr_id,in_wp_stock = False)
	# 	json_result = wcapi.post("products", new_json).json()
	# 	if 'id' in json_result:
	# 		wp_id = json_result['id']
	# 		variation_result = wcapi.post("products/%s/variations" % wp_id, p_variation)
	# 		brand = wcapi.put("products/%s" % wp_id , {'brands':'701'})
			# men_category = wcapi.put("products/%s" % wp_id , {"categories": [{"id": 67}]})
			# women_category = wcapi.put("products/%s" % wp_id , {"categories": [{"id": 238}]})


def sync_stocks(prev_barcode_suffix,cur_barcode_suffix):
	connection = sqlite3.connect("flo.db")
	crsr = connection.cursor()	
	crsr.execute('SELECT * FROM pre_process')
	result = crsr.fetchall()
	print(result,"result")
	for row in result:
		barcode,size_list,price,sales_price,done = row[1],row[2].split('|'),row[3],row[4],row[5]
		print(str(barcode) + "||" + str(size_list)  + "||") 
		prev_barcode = barcode + prev_barcode_suffix 
		print("prev_barcode:" + str(prev_barcode))
		cur_barcode = barcode + cur_barcode_suffix 
		print("current barcode:" + str(cur_barcode))
		print(done,"done")
		if done == 0:
			print("its not done and we are working on it ....")
			add_update(prev_barcode,cur_barcode, size_list, price, sales_price)
			# print("wp_id----------------------")
			# print(prev_barcode)
			# print(wp_id)
			# connection = sqlite3.connect("flo.db")
			# crsr = connection.cursor()	
			print("barcode",barcode)
			crsr.execute('UPDATE pre_process SET done=? WHERE barcode=?',(int(1),barcode))
			print("adding/updating "+ str(barcode) + "\n")
			

			# conn.commit()
	connection.commit()
	connection.close()



sync_stocks("-flwh8","-flwh9")


