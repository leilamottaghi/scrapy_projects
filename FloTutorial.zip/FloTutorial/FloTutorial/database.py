import sqlite3
conn = sqlite3.connect('flo.db')
curr = conn.cursor()
curr.execute("""create table url(
id INTEGER PRIMARY KEY AUTOINCREMENT,

url text UNIQUE, barcode text, done int

)""")
curr.execute("""create table pre_process(id integer primary key, barcode text UNIQUE, size text, price int,sales_price int, done int,url text)""")

curr.execute("""create table pre_process_test(id integer primary key, barcode text, size text, price int,sales_price int, done int,url text)""")
curr.execute("""create table updateurls(id integer primary key, barcode text, size text, price int,sales_price int, done int,url text)""")

curr.execute("""create table product_sku (id integer primary key,wp_sku,wp_id,wp_variation)""")

# id INTEGER PRIMARY KEY AUTOINCREMENT,
# id INTEGER,

# curr.execute("""insert into quotes_tb values (
# 'my title',

# 'my tages'

# # )""")
conn.commit()
conn.close()