import scrapy
from scrapy_splash import SplashRequest
from ..items import LazadaItem
class LaptopSpider(scrapy.Spider):
    name = 'laptop'
    # allowed_domains = ['x']
    # start_urls = ['http://x/']
    # page_number = 2
    # start_urls = [ 'https://www.lazada.com.my/catalog/?q=spm&_keyori=ss&from=input&spm=a2o4k.searchlist.search.go.1aa761fb8eUTRt',]
    # def parse(self, response):
    #     for sel in response.xpath("//div[@class ='_3VkVO']"):
    #         link_list = response.css('div._1MFo_ a::attr(href)').getall()
    #         for link_listi in link_list:
    #             absolute_url = link_listi
    #             yield scrapy.Request(absolute_url, callback=self.parse_attr)
    # def parse_attr(self, response):
    #     items = LazadaItem()
    #     items["link_list"] = response.url
        
    def start_requests(self):
        # page_number = 2
        url = 'https://www.lazada.com.my/catalog/?q=spm&_keyori=ss&from=input&spm=a2o4k.searchlist.search.go.1aa761fb8eUTRt'
        yield SplashRequest(url)

    def parse(self, response):
        products_selector = response.css('[data-tracking="product-card"]')
        for product in products_selector:
        	yield{
        		'name':product.css('a[title]::attr(title)').get(),
        		'price':product.css('span:contains("RM")::text').get(),

        	}
    #     next_page = 'https://www.lazada.com.my/catalog/?_keyori=ss&from=input&page='+ str(LaptopSpider.page_number) + '&q=spm&spm=a2o4k.searchlistcategory.search.go.4bb22a76TvJPxM'
    #     if LaptopSpider.page_number <= 1:
    #         LaptopSpider.page_number +=1
    #         yield response.follow(next_page, callback=self.parse) 