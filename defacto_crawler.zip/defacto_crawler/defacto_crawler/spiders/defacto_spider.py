import scrapy
from ..items import DefactoCrawlerItem
from selenium import webdriver
import time
import sqlite3
# import requests
from scrapy_splash import SplashRequest 

from scrapy.http.request import Request
# from scrapy_splash import SplashRequest
import splash
from scrapy.http import TextResponse 
# from scrapy.contrib import Rule
# from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
# 

class DefactoSpiderSpider(scrapy.Spider):
    name = 'defacto_spider'
#     image_enabled = """function main(splash)
#     splash.images_enabled = false
#     assert(splash:go(splash.args.url))
#     return splash:png()
# end"""
    # allowed_domains = ['defacto.com']
# splash.resource_timeout = 10.0
    
    start_urls = ['https://www.defacto.com.tr/kadin-pantolon']
    # def __init__(self):
    #     self.driver = webdriver.Chrome("F:/scrapy_crawlers/chromedriver.exe")

    BASE_URL="https://www.defacto.com.tr"
    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, callback=self.parse,
                headers={"User-Agent": "My UserAgent"},
                meta={"proxy": "http://127.0.0.1:11080"})
    # def start_requests(self): 
    #     for url in self.start_urls: 
    #         yield SplashRequest(url, self.parse, 
    #             endpoint='render.html', 
    #             args={'wait': 0.5}, 
    #        )
    # def start_requests(self): 
    #     for url in self.start_urls: 
    #         yield SplashRequest(url, self.parse, 
    #             endpoint='render.html', 
    #             args={'wait': 0.5}, 
    #        )


    def parse(self, response):
        # self.driver.get(response.url)
        # response1 = TextResponse(url=response.url, body=self.driver.page_source, encoding='utf-8')
        # time.sleep(5)
        # input("Enter................")
        for sel in response.xpath("//div[@class ='image-box']"):
            link_list = response.css('div.image-box a::attr(href)').getall()
            print(len(link_list),"------link_list")
            for link_listi in link_list:
                absolute_url = self.BASE_URL + link_listi
                # yield scrapy.Request(absolute_url, callback=self.parse_attr)
                yield SplashRequest(absolute_url, callback=self.parse_attr,)


    def parse_attr(self, response):
        # self.driver.get(response.url)
        # response1 = TextResponse(url=response.url, body=self.driver.page_source, encoding='utf-8')
        items = DefactoCrawlerItem()
        items["link_list"] = response.url
        title = response.css('h1.product-card__name::text').extract()[0].strip()
        items["title"] = title
        barcode_str = response.css('div.product-card__code::text').extract()[0].strip()
        barcode = barcode_str.replace("Ürün Kodu:","").strip()
        # barcode_str = browser.find_element_by_class_name("product-card__code").text
        
 
